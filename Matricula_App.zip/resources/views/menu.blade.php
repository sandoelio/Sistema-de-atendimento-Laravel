

<table align="center">
    <tr>
        <td onclick="showForm('/biometria')"  align="center" style="border:2px solid white;padding: 10px">
            <img width="128" class="image image-responsive" src="/assets/imagens/biometria.png" title="Realizar cadastro biométrico ">
            <h4 class="text-center" style="color: white">Cadastro Biométrico&nbsp;&nbsp&nbsp;&nbsp;</h4>

        </td>
        <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </td>
        <td onclick="showForm('/email')"  align="center" style="border:2px solid white;padding: 10px">
            <img width="128" class="image image-responsive" src="/assets/imagens/email.png" title="Criar conta de e-mail institucional">
            <h4 class="text-center" style="color: white">Criar conta e-mail&nbsp;&nbsp&nbsp;&nbsp;</h4>

        </td>
        <td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </td>
        <td onclick="showForm('/problema')" align="center"  style="border:2px solid white;padding: 10px">
            <img width="128" class="image image-responsive" src="/assets/imagens/problema.png" title="Solução de acesso e vinculação de diciplica EAD">
            <h4 class="text-center" style="color: white">Acesso e Disciplina</h4>
            
        </td>
    </tr>
    
</table>
    