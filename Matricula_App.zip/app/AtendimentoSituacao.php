<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AtendimentoSituacao extends Model
{
    protected $table = 'atendimento_situacao';
    public $timestamps = false;
    //
}
