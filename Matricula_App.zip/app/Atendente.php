<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Atendente extends Model
{
    protected $table = 'atendente';
    public $timestamps = false;
    //
}
