<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SinistroProblema extends Model
{
    protected $table = 'sinistro_problema';
    public $timestamps = false;
    //
}
