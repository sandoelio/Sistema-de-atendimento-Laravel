<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SinistroHistorico extends Model
{
    protected $table = 'sinistro_historico';
    public $timestamps = false;
    //
}
