<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sinistro extends Model
{
    protected $table = 'sinistro';
    public $timestamps = false;
    //
}
